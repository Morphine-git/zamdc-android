
#include <jni.h>
#include <GLES2/gl2.h>
#include <android/log.h>
#include <math.h>

#define LOG_TAG "FlycastJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

// --- Simple rotating triangle demo + lifecycle stubs ---

static GLuint gProgram = 0, gVbo = 0;
static GLint  gPosLoc = -1, gColorLoc = -1, gAngleLoc = -1;
static float  gAngle = 0.0f;

static const char* VERT_SRC =
    "attribute vec2 aPos;"
    "uniform float uAngle;"
    "void main(){"
    "  float c = cos(uAngle);"
    "  float s = sin(uAngle);"
    "  vec2 p = vec2(c*aPos.x - s*aPos.y, s*aPos.x + c*aPos.y);"
    "  gl_Position = vec4(p, 0.0, 1.0);"
    "}";

static const char* FRAG_SRC =
    "precision mediump float;"
    "uniform vec3 uColor;"
    "void main(){ gl_FragColor = vec4(uColor, 1.0); }";

static GLuint compileShader(GLenum type, const char* src){
    GLuint sh = glCreateShader(type);
    glShaderSource(sh, 1, &src, 0);
    glCompileShader(sh);
    GLint ok = 0; glGetShaderiv(sh, GL_COMPILE_STATUS, &ok);
    if(!ok){ glDeleteShader(sh); return 0; }
    return sh;
}
static GLuint linkProgram(const char* vs, const char* fs){
    GLuint v = compileShader(GL_VERTEX_SHADER, vs);
    GLuint f = compileShader(GL_FRAGMENT_SHADER, fs);
    if(!v || !f){ if(v) glDeleteShader(v); if(f) glDeleteShader(f); return 0; }
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f);
    glBindAttribLocation(p, 0, "aPos");
    glLinkProgram(p);
    glDeleteShader(v); glDeleteShader(f);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if(!ok){ glDeleteProgram(p); return 0; }
    return p;
}
static void demoInit(){
    glClearColor(0.08f, 0.08f, 0.08f, 1.0f);
    gProgram = linkProgram(VERT_SRC, FRAG_SRC);
    const GLfloat verts[] = { 0.0f,0.6f, -0.6f,-0.6f,  0.6f,-0.6f };
    glGenBuffers(1,&gVbo); glBindBuffer(GL_ARRAY_BUFFER,gVbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER,0);
    gPosLoc=0; gColorLoc=glGetUniformLocation(gProgram,"uColor");
    gAngleLoc=glGetUniformLocation(gProgram,"uAngle");
}
static void demoResize(int w,int h){ glViewport(0,0,w,h); }
static void demoRender(){
    glClear(GL_COLOR_BUFFER_BIT);
    if(!gProgram) return;
    glUseProgram(gProgram);
    gAngle += 0.03f; if(gAngle>6.2831853f) gAngle-=6.2831853f;
    float r=0.5f+0.5f*sinf(gAngle*0.7f);
    float g=0.5f+0.5f*sinf(gAngle*1.1f+2.0f);
    float b=0.5f+0.5f*sinf(gAngle*1.3f+4.0f);
    glUniform3f(gColorLoc,r,g,b);
    glUniform1f(gAngleLoc,gAngle);
    glBindBuffer(GL_ARRAY_BUFFER,gVbo);
    glEnableVertexAttribArray(gPosLoc);
    glVertexAttribPointer(gPosLoc,2,GL_FLOAT,GL_FALSE,2*sizeof(GLfloat),(const void*)0);
    glDrawArrays(GL_TRIANGLES,0,3);
    glDisableVertexAttribArray(gPosLoc);
    glBindBuffer(GL_ARRAY_BUFFER,0);
    glUseProgram(0);
}

extern "C" {

// Activity lifecycle (so no UnsatisfiedLinkError)
JNIEXPORT void JNICALL Java_com_flycast_wrapper_NativeGLActivity_nativeOnResume(JNIEnv*, jclass){ LOGI("onResume"); }
JNIEXPORT void JNICALL Java_com_flycast_wrapper_NativeGLActivity_nativeOnPause(JNIEnv*, jclass){ LOGI("onPause"); }
JNIEXPORT void JNICALL Java_com_flycast_wrapper_NativeGLActivity_nativeOnDestroy(JNIEnv*, jclass){ LOGI("onDestroy"); }

// Renderer hooks used by your GLSurfaceView.Renderer
JNIEXPORT void JNICALL Java_com_flycast_wrapper_RendererImpl_nativeInit(JNIEnv*, jclass){ demoInit(); }
JNIEXPORT void JNICALL Java_com_flycast_wrapper_RendererImpl_nativeResize(JNIEnv*, jclass, jint w, jint h){ demoResize(w,h); }
JNIEXPORT void JNICALL Java_com_flycast_wrapper_RendererImpl_nativeRender(JNIEnv*, jclass){ demoRender(); }

} // extern "C"
