package com.flycast.wrapper;

public class Core {
    static {
        System.loadLibrary("flycast-jni");
    }

    // Native API
    public static native void init();
    public static native void loadBios(String path);
    public static native void loadGame(String path);
    public static native void runFrame();
    public static native void onInput(int code, boolean pressed);
    public static native void saveState(String path);
    public static native void loadState(String path);
    public static native void shutdown();
}
