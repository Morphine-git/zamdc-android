package com.flycast.wrapper;

import android.app.Activity;
import android.os.Bundle;
import android.view.WindowManager;

public class NativeGLActivity extends Activity {

    private GLView glView;

    static {
        try {
            System.loadLibrary("flycast-jni"); // JNI bridge only
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Keep screen on while playing
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Create and attach GLSurfaceView
        glView = new GLView(this);
        setContentView(glView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (glView != null) glView.onResume();
        nativeOnResume();
    }

    @Override
    protected void onPause() {
        nativeOnPause();
        if (glView != null) glView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        nativeOnDestroy();
        super.onDestroy();
    }

    // ---- JNI hooks implemented in flycast_jni.cpp ----
    private static native void nativeOnResume();
    private static native void nativeOnPause();
    private static native void nativeOnDestroy();
}
